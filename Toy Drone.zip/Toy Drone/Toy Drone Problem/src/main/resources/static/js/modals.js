function deleteFinance(finNum, name, type, path) {
    event.stopPropagation();
    deleteForm.setAttribute("action", path);
    $('#delModal').find('.modal-body p').text('Do you want to delete \"' + name + '\"?');
    $('#delModal').find('#delLabel').text('Delete ' + type);
    $('#delModal').find('#financeNum').val(finNum);
    $('#delModal').modal('show');
}

function deleteCustomer(customerNum, name, type, path) {
    event.stopPropagation();
    deleteCustomerForm.setAttribute("action", path);
    $('#delCusModal').find('.modal-body p').text('Do you want to delete \"' + name + '\"?');
    $('#delCusModal').find('#deleteLabel').text('Delete ' + type);
    $('#delCusModal').find('#customerNum').val(customerNum);
    $('#delCusModal').modal('show');
}

function editEvent(eventNum, month, type, amount, keepRepayment, path) {
    if (type == "Deposit") {
        depositForm.setAttribute("action", path);
        $('#dModal').find('#eventNum').val(eventNum);
        $('#dModal').find('#eventType').val(type);
        $('#dModal').find('#dTerm').val(month);
        $('#dModal').find('#amount').val(amount);
        $('#dModal').find('#dKeepRepayment').val(keepRepayment);
        $('#dModal').modal('show');
    } else if (type == "Withdraw") {
        withdrawForm.setAttribute("action", path);
        $('#wModal').find('#eventNum').val(eventNum);
        $('#wModal').find('#eventType').val(type);
        $('#wModal').find('#wTerm').val(month);
        $('#wModal').find('#amount').val(amount);
        $('#wModal').find('#wKeepRepayment').val(keepRepayment);
        $('#wModal').modal('show');
    } else if (type == "Change Rate") {
        changeRateForm.setAttribute("action", path);
        $('#crModal').find('#eventNum').val(eventNum);
        $('#crModal').find('#eventType').val(type);
        $('#crModal').find('#crTerm').val(month);
        $('#crModal').find('#rate').val(amount);
        $('#crModal').find('#crKeepRepayment').val(keepRepayment);
        $('#crModal').modal('show');
    } else if (type == "Change Amount") {
        changeAmountForm.setAttribute("action", path);
        $('#caModal').find('#eventNum').val(eventNum);
        $('#caModal').find('#eventType').val(type);
        $('#caModal').find('#caTerm').val(month);
        $('#caModal').find('#amount').val(amount);
        $('#caModal').modal('show');
    } else if (type == "Increase Amount") {
        increaseAmountForm.setAttribute("action", path);
        $('#iaModal').find('#eventNum').val(eventNum);
        $('#iaModal').find('#eventType').val(type);
        $('#iaModal').find('#iaTerm').val(month);
        $('#iaModal').find('#amount').val(amount);
        $('#iaModal').modal('show');
    }
}
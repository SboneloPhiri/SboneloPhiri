package src.main.java.toydrone;

import javafx.scene.layout.Border;

import javax.swing.*;
import java.awt.*;

public class ToyDroneRunner extends JFrame {

  private ToyDrone toyDrone;
  JPanel panel = new JPanel();

  public ToyDroneRunner(ToyDrone toyDrone) {
    super("Toy Drone");
    this.toyDrone = toyDrone;
    setSize(toyDrone.getX(), toyDrone.getY());
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setVisible(true);
    JButton button = new JButton("Drone");

    panel.setSize(250, 250);
    panel.setVisible(true);
    panel.setLayout(new BorderLayout());

    button.setSize(100,100);
    button.setBackground(Color.blue);
    button.setBounds(100,100,100,100);

    panel.add(button,BorderLayout.SOUTH);
    add(panel);

  }

  private static void setLookAndFeel() {
    try {
      UIManager.setLookAndFeel(
          "javax.swing.plaf.nimbus.NimbusLookAndFeel"
      );
    } catch (Exception exc) {
      // ignore error
    }
  }

  public void placeDrone(int x, int y){
    if(checkIfPositionExist(x, y)){
      add(new JButton("Drone"));
    }
  }

  public boolean checkIfPositionExist(int x, int y){
    if((x <= toyDrone.getX() && x >= 0) && (y <= toyDrone.getY() && y >= 0)){
      return true;
    }
    return false;
  }

  public static void main(String[] arguments) {
    setLookAndFeel();
    ToyDrone toyDrone = new ToyDrone(1000, 1000);

    ToyDroneRunner sf = new ToyDroneRunner(toyDrone);
    sf.placeDrone(100, 100);
  }
}

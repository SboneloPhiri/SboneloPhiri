package javafx.scene.layout;

public class Border {

}


from doctest import master
import fileinput
from logging import root
import time
import math
##from msilib.schema import SelfReg

import turtle
import random
from tkinter import *
from tkinter import ttk
from tkinter import messagebox

from tkinter import *
from typing import Self

##import formatter
'''
We willl assume that 10 units is equavalent to 1000 units for better simulation.
Therefore to move one unit, we will move by 100.
In a nutshell scale 10 = 1000
1 = 100
'''


# Create the surface - the playground

surface = turtle.Screen()


global_direction = ""
turtle.screensize(canvwidth=1000, canvheight=1000)
turtle.bgpic("space.png")
turtle.bgpic()
surface.title("Toy Drone")


##globalvariables
  
# TextBox Creation
ws = turtle.Screen()
ws.setup(700, 500)



ws.addshape('drone.gif')
##surface.shape('drone.gif')

input_text = turtle.textinput("Enter your input :", "Enter a sequence of commands") 
print(input_text)
ws.title("toy Drone")
print("INPUT TEXT",input_text)


drone = turtle.Turtle()
# drone.shape("drone.gif")
drone.shape("turtle")
drone.pencolor("red")
drone.speed(1)
##drone.setheading(0.0)


     ##convert N,E,S,W to 90,180,270,360
     
def convert_to_angle(face:str)->int:
    if face == "NORTH":
        return 90
    if face == "WEST":
        return 180
    if face == "SOUTH":
        return 270
    if face == "EAST":
        return 360
    return 0

def convert_to_direction(angle:float)->str:
    if angle  == 90.0:
        
        return "NORTH"
    
    if angle == 180.0:
        
        return "WEST"
    
    if angle == 270.0:
        return "SOUTH"
    
    if angle == 0.0 or angle == 360.0 :
        
        return "EAST"



##inputdialogue.mainloop()
def setDefaultPos(command:str):
    global_direction =""
    print("----------------------------------------------------------------------------------------------------")
    print("*******PLACE A DRONE IN DEFAULT POSITION*******")
    commands = command.split(" ")
     # place the drone on the surface
    xpos = float(commands[1].split(",")[0])
    ypos = float(commands[1].split(",")[1])
    direction = (commands[1].split(",")[2])
    drone.goto(xpos,ypos)
    ##drone.setheading()
    #drone.setheading()
    print("SET DEFAULT POSITION",xpos," :",ypos,str(direction))
    global_direction = drone.heading()
    
def PLACE(command:str):
    # validate command
    ##answer = input(' choose the shape triangle, square or pentagon')
    print("----------------------------------------------------------------------------------------------------")
    print("*******PLACE command started*******")
    commands = command.split(" ")
    print("SPLITTED COMMANDS :",commands)
    if commands[0] != "PLACE":
        print("Invalid first command")
        return 
    print("*******PLACE command complete*******")
    print("----------------------------------------------------------------------------------------------------")
def Execute(command:str):
    print("----------------------------------------------------------------------------------------------------")
    print("********EXECUTION STARTED********")
    commands = command.split(" ")
    for i in range(2,len(commands)):
        if commands[i] == 'LEFT':
            LEFT(convert_to_angle(commands[i]))
        if commands[i] == 'ATTACK':
            ATTACK()
              
        if commands[i] == 'RIGHT':
            RIGHT(convert_to_angle(commands[i]))
            
        if commands[i] == 'MOVE':
            #MOVE(float(commands[1].split(",")[0]),float(commands[1].split(",")[1]))
            print("*********MOVE command started********")
            if (convert_to_direction(drone.heading()) == "EAST"):
                drone.setposition(drone.xcor()+1.0,drone.ycor())
                print(drone.position()," EAST")
                print("**********MOVE command complete**************")
                
            if (convert_to_direction(drone.heading()) == "WEST"):
                drone.setposition(drone.xcor()-1.0,drone.ycor())
                print(drone.position()," WEST")
                print("**********MOVE command complete**************")
                
            if (convert_to_direction(drone.heading()) == "SOUTH"):
                drone.setposition(drone.xcor(),drone.ycor()-1.0)
                print(drone.position()," SOUTH")
                print("**********MOVE command complete**************")
                
            if (convert_to_direction(drone.heading()) == "NORTH"):
                drone.setposition(drone.xcor(),drone.ycor()+1.0)
                print(drone.position()," :NORTH")
                print("**********MOVE command complete**************")
            
        if commands[i] == 'REPORT':
            REPORT()
    
    print("***********EXECUTION complete********************")
    print("----------------------------------------------------------------------------------------------------")
    ##drone.hideturtle()
   ##print("CURRENTLY HEADING",turtle.heading())
            
    
    
                

#TURN RIGHT FUNCTION
def LEFT(angle:float):
    global_direction = ""
    ##drone.setheading(270)
    ##if drone.setheading(convert_to_angle(angle)) == 180:
    drone.left(90.0)
        
    ##drone.left(90)
    print("----------------------------------------------------------------------------------------------------")
    print("*******LEFT command started*******")
    print(convert_to_direction(drone.heading()))
    print(drone.position())
    print("*******LEFT command complete*********")
    print("----------------------------------------------------------------------------------------------------")
    global_direction = str(convert_to_direction(drone.heading()))
      
#TURN LEFT FUNCTION
def RIGHT(angle:float):
    print("----------------------------------------------------------------------------------------------------")
    print("*******RIGHT command complete*******")
    
    global_direction = ""
    #if drone.setheading(convert_to_angle(angle)) == 180:
    drone.right(90.0)
    ##print(drone.heading())
    
    
    print(convert_to_direction(drone.heading()))
    print(drone.position())
    print("********RIGHT command complete*******")
    print("----------------------------------------------------------------------------------------------------")
    global_direction = str(convert_to_direction(drone.heading()))
  
##ATTACK FUNCTION
def ATTACK():
    global_direction = ""
    print("----------------------------------------------------------------------------------------------------")
    print("*******ATTACKED command started*******")
    #defaultMove()
    ##drone.forward(1) 
    for i in range(300):
        drone.speed(0)
        angle = random.randint(0,45)
        distance = random.randint(0,20)
        drone.right(angle)
        drone.forward(distance)
        drone.backward(distance)
        ##drone.heading() == 90
    ##print(drone.heading())
    ##print(drone.position())
    print(convert_to_direction(drone.heading()))
    print("*********ATTACK command complete**********")
    print("----------------------------------------------------------------------------------------------------")
    global_direction = str(convert_to_direction(drone.heading()))
    
def defaultMove():
    drone.forward(1) 
 
def AttackPreviousDirection(command:str)-> str:
    commands = command.split(" ")
    previousDirection = " "
    for i in range(2,len(commands)):
        if (commands[i] == "REPORT") and (commands[i-1] != "ATTACK"):
            previousDirection=drone.heading()
            return previousDirection
        else :
            previousDirection=drone.heading()
            return previousDirection
    print("Previous Direction :",previousDirection)          
         
def MOVE(x:float,y:float):
    #drone.forward(1)
    print("----------------------------------------------------------------------------------------------------")
    print("*******MOVE command started*******")
    global_direction = ""
    if(convert_to_direction(drone.heading()) == "NORTH"):
        drone.setposition(x,y+1) 
    
    if(convert_to_direction(drone.heading()) == "SOUTH"):
        drone.setposition(x,y-1) 
        
    if(convert_to_direction(drone.heading()) == "EAST"):
        drone.setposition(x+1,y) 
        
    if(convert_to_direction(drone.heading()) == "WEST"):   
        drone.setposition(x-1,y)  
        
        
    ##print(drone.heading())
    ##print(drone.setposition)
    
    print(drone.heading())
    print(convert_to_direction(drone.heading()))
    print(drone.position())
    print("*******MOVE command complete*******")
    print("----------------------------------------------------------------------------------------------------")
    global_direction = str(convert_to_direction(drone.heading()))
  
    
def REPORT():
    ##AttackPreviousDirection()
    print("----------------------------------------------------------------------------------------------------")
    print("*******REPORT command started*******")
    print("Report X & Y Cordinates : ",drone.position())
    print(" Direction : ",convert_to_direction(drone.heading()))
    ##messagebox.showinfo(str(drone.xcor),str(drone.ycor))
    #results = drone.pos(),convert_to_direction(drone.heading())
    
    
    results = "REPORT "+str(drone.position())+" FACING "+" : "+global_direction
    messagebox.showinfo("REPORT : ",results)
    print("REPORT :",results)
    ##print(10*drone.xcor()/10)

##play(sample_input) 

PLACE(input_text)
print("----------------------------------------------------------------------------------------------------")
setDefaultPos(input_text)
print("----------------------------------------------------------------------------------------------------")
Execute(input_text) #you named this as play yesterday
##Direction = Label(AttackPreviousDirection(input_text), text="Direction", fg="red")
##messagebox.Message(Direction)



surface.mainloop()
##messagebox.Message(text)




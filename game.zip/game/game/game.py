
import fileinput
from logging import root
import time
##from msilib.schema import SelfReg

import turtle
import random
from tkinter import *
from tkinter import ttk
from tkinter import messagebox

from tkinter import *
from typing import Self

##import formatter
'''
We willl assume that 10 units is equavalent to 1000 units for better simulation.
Therefore to move one unit, we will move by 100.
In a nutshell scale 10 = 1000
1 = 100
'''


# Create the surface - the playground

surface = turtle.Screen()



turtle.screensize(canvwidth=1000, canvheight=1000)
turtle.bgpic("space.png")
turtle.bgpic()
surface.title("Toy Drone")


##globalvariables
  
# TextBox Creation
ws = turtle.Screen()
ws.setup(1000, 1000)


ws.addshape('drone.gif')
##surface.shape('drone.gif')

input_text = turtle.textinput("Enter your input :", "Enter a sequence of commands") 
print(input_text)
ws.title("toy Drone")
print("INPUT TEXT",input_text)


drone = turtle.Turtle()
# drone.shape("drone.gif")
drone.shape("turtle")
drone.pencolor("red")
drone.speed(1)


     ##convert N,E,S,W to 90,180,270,360
     
def convert_to_angle(face:str)->int:
    if face == "NORTH":
        return 90
    if face == "WEST":
        return 180
    if face == "SOUTH":
        return 270
    if face == "EAST":
        return 360
    return 0

def convert_to_direction(angle:float)->str:
    if angle == 90:
        return "NORTH"
    if angle == 180:
        return "WEST"
    if angle == 270:
        return "SOUTH"
    if angle == 360:
        return "EAST"
    return 0



##inputdialogue.mainloop()

def PLACE(command:str):
    # validate command
    ##answer = input(' choose the shape triangle, square or pentagon')
    print("*******PLACE COMMAND STARTED*******")
    commands = command.split(" ")
    print("Splitted Commands :",commands)
    if commands[0] != "PLACE":
        print("Invalid first command")
        return 
    # place the drone on the surface
    drone_xpos = float(commands[1].split(",")[0])
    drone_ypos = float(commands[1].split(",")[1])
    #print("X position :",drone_xpos)
    #print("Y Position :",drone_ypos)
    drone_direction = commands[1].split(",")[2]
    print("Drone Direction :",drone_direction)
    drone.goto(drone_xpos,drone_ypos)
    drone.setheading(convert_to_direction(drone_direction))
    print("ANGLE DIRECTIONS :",drone.heading())
    print(command.split(" "))
    print("DRONE DIRECTION :",drone_direction)
    print("DRONE POSITION :","(",drone_xpos,drone_ypos,")")
    print("*******PLACE COMMAND COMPLETE*******")
    
def Execute(command:str):
    
    ##print("********POST PLACE COMMAND********")
    commands = command.split(" ")
    for i in range(2,len(commands)):
        if commands[i] == 'LEFT':
            LEFT(convert_to_angle(commands[i]))
        if commands[i] == 'ATTACK':
            ATTACK()
              
        if commands[i] == 'RIGHT':
            RIGHT(convert_to_angle(commands[i]))
            
        if commands[i] == 'MOVE':
            MOVE()

        if commands[i] == 'REPORT':
            REPORT()
    
            ##print("---REPORT command complete---")
    ##drone.hideturtle()
    print("CURRENTLY HEADING",turtle.heading())
            
    
    
                

#TURN RIGHT FUNCTION
def LEFT(angle:float):
    ##drone.setheading(270)
    if drone.setheading(convert_to_angle(angle)) == 180:
        drone.left(270)
    
    if drone.setheading(convert_to_angle(angle)) == 360 or drone.setheading(convert_to_angle(angle)) == 0:
        drone.left(90)
        
    if drone.setheading(convert_to_angle(angle)) == 90:
        drone.left(180)
        
    if drone.setheading(convert_to_angle(angle)) == 270:
        drone.left(360)
    
        
    ##drone.left(90)
    print("---LEFT command complete---")
      
#TURN LEFT FUNCTION
def RIGHT(angle:float):
    if drone.setheading(convert_to_angle(angle)) == 180:
        drone.right(90)
    
    if drone.setheading(convert_to_angle(angle)) == 360 or drone.setheading(convert_to_angle(angle)) == 0:
        drone.right(270)
        
    if drone.setheading(convert_to_angle(angle)) == 90:
        drone.right(360)
        
    if drone.setheading(convert_to_angle(angle)) == 270:
        drone.right(180)
    ##drone.setheading(360)
    print("---RIGHT command complete---")
  
##ATTACK FUNCTION
def ATTACK():
    print("---ATTACKED command started---")
    drone.forward(100) 
    for i in range(300):
        drone.speed(0)
        angle = random.randint(0,45)
        distance = random.randint(0,40)
        drone.right(angle)
        drone.forward(distance)
        drone.backward(distance)
              
def MOVE():
    drone.forward(1) 
    print("---MOVE command complete---")
    
def REPORT():
    print("---REPORT command started---")
    print("Report X & Y Cordinates : ",drone.pos())
    print("Report Direction : ",convert_to_direction(drone.heading()))
    ##messagebox.showinfo(str(drone.xcor),str(drone.ycor))
    results = drone.pos(),convert_to_direction(drone.heading())
    messagebox.Message(results)

##play(sample_input) 
PLACE(input_text)
Execute(input_text) #you named this as play yesterday

surface.mainloop()





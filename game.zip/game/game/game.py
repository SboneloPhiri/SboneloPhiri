
from doctest import master
import fileinput
from logging import root
import time
import math
##from msilib.schema import SelfReg

import turtle
import random
from tkinter import *
from tkinter import ttk
from tkinter import messagebox

from tkinter import *
from typing import Self

##import formatter
'''
We willl assume that 10 units is equavalent to 1000 units for better simulation.
Therefore to move one unit, we will move by 100.
In a nutshell scale 10 = 1000
1 = 100
'''


# Create the surface - the playground

surface = turtle.Screen()



turtle.screensize(canvwidth=1000, canvheight=1000)
turtle.bgpic("space.png")
turtle.bgpic()
surface.title("Toy Drone")


##globalvariables
  
# TextBox Creation
ws = turtle.Screen()
ws.setup(700, 500)



ws.addshape('drone.gif')
##surface.shape('drone.gif')

input_text = turtle.textinput("Enter your input :", "Enter a sequence of commands") 
print(input_text)
ws.title("toy Drone")
print("INPUT TEXT",input_text)


drone = turtle.Turtle()
# drone.shape("drone.gif")
drone.shape("turtle")
drone.pencolor("red")
drone.speed(1)


     ##convert N,E,S,W to 90,180,270,360
     
def convert_to_angle(face:str)->int:
    if face == "NORTH":
        return 90
    if face == "WEST":
        return 180
    if face == "SOUTH":
        return 270
    if face == "EAST":
        return 360
    return 0

def convert_to_direction(angle:float)->str:
    if angle >= 0.0 and angle <=90.0:
        return "NORTH"
    if angle >= 91.0 and angle <=179.0:
        return "WEST"
    if angle <= 180.0 and angle<=269.0:
        return "SOUTH"
    if angle >= 270.0 or angle <= 360.0 :
        return "EAST"
    return 0



##inputdialogue.mainloop()
def setDefaultPos(command:str):
    print("*******PLACE A DRONE IN DEFAULT POSITION*******")
    commands = command.split(" ")
     # place the drone on the surface
    xpos = float(commands[1].split(",")[0])
    ypos = float(commands[1].split(",")[1])
    direction = (commands[1].split(",")[2])
    drone.goto(xpos,ypos)
    drone.setheading(90.0)
    #drone.setheading()
    print("SET DEFAULT POSITION",xpos," :",ypos,str(direction))
    
def PLACE(command:str):
    # validate command
    ##answer = input(' choose the shape triangle, square or pentagon')
    print("*******PLACE COMMAND STARTED*******")
    commands = command.split(" ")
    print("SPLITTED COMMANDS :",commands)
    if commands[0] != "PLACE":
        print("Invalid first command")
        return 
def Execute(command:str):
    
    ##print("********POST PLACE COMMAND********")
    commands = command.split(" ")
    for i in range(2,len(commands)):
        if commands[i] == 'LEFT':
            LEFT(convert_to_angle(commands[i]))
        if commands[i] == 'ATTACK':
            ATTACK()
              
        if commands[i] == 'RIGHT':
            RIGHT(convert_to_angle(commands[i]))
            
        if commands[i] == 'MOVE':
            MOVE(float(commands[1].split(",")[0]),float(commands[1].split(",")[1]))

        if commands[i] == 'REPORT':
            REPORT()
    
            ##print("---REPORT command complete---")
    ##drone.hideturtle()
   ##print("CURRENTLY HEADING",turtle.heading())
            
    
    
                

#TURN RIGHT FUNCTION
def LEFT(angle:float):
    ##drone.setheading(270)
    ##if drone.setheading(convert_to_angle(angle)) == 180:
    drone.left(90.0)
        
    ##drone.left(90)
    print("*******LEFT command complete*******")
    print(drone.heading())
    print(drone.position())
    print("************************************")
  
      
#TURN LEFT FUNCTION
def RIGHT(angle:float):
    #if drone.setheading(convert_to_angle(angle)) == 180:
    drone.right(90.0)
    ##print(drone.heading())
    
    print("*******RIGHT command complete*******")
    print(drone.heading())
    print(drone.position())
    print("************************************")
  
##ATTACK FUNCTION
def ATTACK():
    print("*******ATTACKED command started*******")
    defaultMove()
    ##drone.forward(1) 
    for i in range(300):
        drone.speed(0)
        angle = random.randint(0,45)
        distance = random.randint(0,20)
        drone.right(angle)
        drone.forward(distance)
        drone.backward(distance)
        ##drone.heading() == 90
    ##print(drone.heading())
    ##print(drone.position())
    print("************************************")
    
def defaultMove():
    drone.forward(1) 
 
def AttackPreviousDirection(command:str)-> str:
    commands = command.split(" ")
    previousDirection = " "
    for i in range(2,len(commands)):
        if (commands[i] == "REPORT") and (commands[i-1] != "ATTACK"):
            previousDirection=drone.heading()
            return previousDirection
        else :
            previousDirection=drone.heading()
            return previousDirection
    print("Previous Direction :",previousDirection)          
         
def MOVE(x:float,y:float):
    ##drone.forward(1)
    
    if(convert_to_direction(drone.heading()) == "NORTH"):
        drone.setposition(x,y+1) 
    
    if(convert_to_direction(drone.heading()) == "SOUTH"):
        drone.setposition(x,y-1) 
        
    if(convert_to_direction(drone.heading()) == "EAST"):
        drone.setposition(x+1,y) 
        
    if(convert_to_direction(drone.heading()) == "WEST"):   
        drone.setposition(x-1,y)  
        
        
    ##print(drone.heading())
    ##print(drone.setposition)
    print("*******MOVE command complete*******")
    print(convert_to_direction(drone.heading()))
    print(drone.position())
    print("************************************")
  
    
def REPORT():
    ##AttackPreviousDirection()
    print("*******REPORT command started*******")
    print("Report X & Y Cordinates : ",drone.position())
    print(" Direction : ",convert_to_direction(drone.heading()))
    ##messagebox.showinfo(str(drone.xcor),str(drone.ycor))
    #results = drone.pos(),convert_to_direction(drone.heading())
    
    
    results = "RESULTS ("+str(drone.position())+") FACING "+" : "+str(convert_to_direction(drone.heading()))
    messagebox.showinfo("REPORT ",results)
    print("RESULTS :",results)
    ##print(10*drone.xcor()/10)

##play(sample_input) 

PLACE(input_text)
setDefaultPos(input_text)
Execute(input_text) #you named this as play yesterday
##Direction = Label(AttackPreviousDirection(input_text), text="Direction", fg="red")
##messagebox.Message(Direction)



surface.mainloop()
##messagebox.Message(text)



